<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BAAk Link</title>

    <link rel="stylesheet" href="<?= base_url('assets/css/bosstraps.min.css?v=' . time()) ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=' . time()) ?>">

    <link rel="icon" href="assets/img/logo.png" type="image/png">
</head>

<body>